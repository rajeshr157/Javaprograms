package com.sankir;

public interface ConvertString {
  public String convert(String s, char ch);
}
