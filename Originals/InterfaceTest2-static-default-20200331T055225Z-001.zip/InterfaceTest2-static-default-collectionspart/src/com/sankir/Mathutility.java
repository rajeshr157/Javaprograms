package com.sankir;

public interface Mathutility {

  // static methods are at Interface level
  static int square(int n) {
    return n * n;
  };

  static int cube(int n) {
    return n * n * n;
  };


}
