package com.sankir;

public interface PowerofUtility {

  public double  tothepowerof(double n, double p);
}
